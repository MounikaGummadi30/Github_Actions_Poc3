#!/bin/bash
echo "Deployment successful"
